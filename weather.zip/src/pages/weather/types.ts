import { ReactNode } from 'react'

export interface WeatherProps {
  children: ReactNode
}