import Weather from "./Weather";

export default Weather