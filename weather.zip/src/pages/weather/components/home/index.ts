import WeatherHome from "./WeatherHome";

export default WeatherHome;