import { ChangeEvent, useState } from 'react';

import WeatherInfo from "../weatherInfo";
import { InputButtonWrapper, InputInfoCardWrapper } from './styles';
import WeatherButton from '../weatherButton';
import WeatherInput from '../weatherInput';
import { AppDispatch } from 'store/store';
import { useDispatch, useSelector } from 'react-redux';
import { weatherSelector } from 'store/redux/weather/selectors';
import { getWeatherInfo, weatherActions } from 'store/redux/weather/weatherSlice';


interface WeatherInfoData {
  temp: string  
  icon: string
  cityName: string
}

interface WeatherErrorData {
  code: string
  message: string
}

function WeatherHome() {
  const dispatch: AppDispatch = useDispatch()
  const {weatherCard, weatherCardsArray, error, isLoading} = useSelector(weatherSelector)

  const [weatherInfo, setWeatherInfo] = useState<WeatherInfoData | undefined>(undefined)
  const [weatherError, setWeatherError] = useState<WeatherErrorData | undefined>(undefined)
  const [city, setCity] = useState<string>("")
  const onChangeCity = (event: ChangeEvent<HTMLInputElement>) => {
    setCity(event.target.value)
  }

  return (
    <InputInfoCardWrapper>
      <InputButtonWrapper>
        <WeatherInput
          placeholder="Enter city name"
          value={city}
          onChange={onChangeCity}
        />
        <WeatherButton
          name="Search"
          onClick={() => {
            dispatch(getWeatherInfo(city))
          }}
        />
      </InputButtonWrapper>

      {weatherCard && (
        <WeatherInfo
          temp={weatherCard.temp}
          icon={weatherCard.icon}
          cityName={weatherCard.cityName}
          isShowOnlyDeleteButton={true}
          onDelete={() => {
            setWeatherInfo(undefined)
          }}
        />
      )}
    </InputInfoCardWrapper>
  )
}

export default WeatherHome;

