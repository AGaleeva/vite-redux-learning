import Weathers from "./Weathers";

export default Weathers;