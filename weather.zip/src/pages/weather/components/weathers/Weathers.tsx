function Weathers() {
  return (
    <>
      Weathers
    </>
  )
}

export default Weathers;