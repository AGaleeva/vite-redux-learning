import WeatherInput from './WeatherInput';

export default WeatherInput;