export interface FeedbackInitialStates {
  likes: number
  dislikes: number
}