import CatFacts from "./CatFacts";

export default CatFacts;