import TodoList from "components/todoList";

function Homework33() {
  return (
    <>
      <TodoList />
    </>
  )
}

export default Homework33;