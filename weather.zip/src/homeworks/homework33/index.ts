import Homework33 from "./Homework33";

export default Homework33;