import Feedback from "components/feedback";

function Homework31() {
  return (
    <>
      <Feedback />
    </>
  )
}

export default Homework31;