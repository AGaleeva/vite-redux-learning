import Lesson30 from "./Lesson30";

export default Lesson30;