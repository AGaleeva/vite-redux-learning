export interface User {
  firstLastName: string,
  age: string,
  jobTitle: string
}

export interface UsersState {
  users : User[]
}