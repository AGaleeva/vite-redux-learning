export interface CounterInitialState {
  count: number
}